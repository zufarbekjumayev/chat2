# Chat App for Railway
Deploy this to Railway with FastAPI + Redis + WebSocket.

## To Run Locally:
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

## Railway Start Command:
```
uvicorn main:app --host 0.0.0.0 --port $PORT
```
