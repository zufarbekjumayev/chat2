
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import redis.asyncio as redis
import asyncio
import os
from urllib.parse import urlparse

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Railway Redis URL
redis_url = urlparse(os.getenv("REDIS_URL", "rediss://default:password@localhost:6379"))
redis_client = redis.Redis(
    host=redis_url.hostname,
    port=redis_url.port,
    password=redis_url.password,
    ssl=True
)

connected_clients = []

@app.get("/")
async def get():
    with open("templates/index.html") as f:
        return HTMLResponse(content=f.read(), status_code=200)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    connected_clients.append(websocket)

    try:
        pubsub = redis_client.pubsub()
        await pubsub.subscribe("chat")

        async def read_redis():
            while True:
                message = await pubsub.get_message(ignore_subscribe_messages=True, timeout=1.0)
                if message:
                    for client in connected_clients:
                        await client.send_text(message['data'].decode())

        asyncio.create_task(read_redis())

        while True:
            data = await websocket.receive_text()
            await redis_client.publish("chat", data)

    except:
        connected_clients.remove(websocket)
        await websocket.close()
